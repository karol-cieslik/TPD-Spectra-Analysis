from pathlib import Path
import json,zipfile,hashlib,subprocess,sys,time
from scripts.experimental_multipeak_check import SOURCE,ROOT,load
cfg=json.loads((SOURCE/'protocol.json').read_text());z=zipfile.ZipFile('/tmp/tpd_ice_table2.zip');member=next(n for n in z.namelist() if n.startswith('Files_') and '18_binary_CO' in n);b=z.read(member);(SOURCE/'raw/18_binary_CO.csv').write_bytes(b)
c=dict(name='CO18_separated',member=member,raw_file='raw/18_binary_CO.csv',sha256=hashlib.sha256(b).hexdigest(),signal_column=1,window_K=[25,170],description='Separated CO release; low-temperature and high-temperature peaks')
# The strict native-point screen also found nine repeated temperatures.
# Pool repeated adjacent temperatures by arithmetic mean, as the production
# fitter does, and preserve the unchanged original separately.
import numpy as np,io
a=np.loadtxt(io.BytesIO(b),delimiter=';',comments='#');a=a[(a[:,0]>=25)&(a[:,0]<=170)];assert np.all(np.diff(a[:,0])>=0)
u,inv=np.unique(a[:,0],return_inverse=True);pooled=np.column_stack([u]+[np.bincount(inv,weights=a[:,j])/np.bincount(inv) for j in [1,2]])
derived=SOURCE/'raw/18_binary_CO_adjacent_mean.csv';np.savetxt(derived,pooled,delimiter=';',header='Temperature;CO;H2O\nK;ML/K;ML/K',comments='#')
c['original_sha256']=c['sha256'];c['original_raw_file']=c['raw_file'];c['raw_file']='raw/'+derived.name;c['sha256']=hashlib.sha256(derived.read_bytes()).hexdigest();c['duplicate_points_pooled']=len(a)-len(u)
T,y,excluded=load(c,cfg);print('source screened',len(T),flush=True)
cfg['input_policy']='25-170 K; nondecreasing finite original input; pool nine adjacent duplicate temperatures by mean; no interpolation, no sorting, no smoothing; same unique points used for all models.';cfg['cases']=[c];cfg['scope']='Follow-up frozen before fitting after CO12 source correspondence concern. CO18 original 20-170 K has temperature reversals below 25 K; use 25-170 K native points without sorting; nine repeated-temperature pairs pooled by mean before fitting, with all originals retained. No recovery claim for the excluded 20-25 K leading edge.'
(SOURCE/'separated_protocol.json').write_text(json.dumps(cfg,indent=2)+'\n');out=SOURCE/'separated_assessment';out.mkdir();results=[]
for i,task in enumerate([dict(states=1,order=n) for n in [0,1,2]]+[dict(states=2,order=1,initial_energies_eV=e) for e in cfg['two_state_initial_energies_eV']]):
 dest=out/f'CO18_{i}.json';start=time.monotonic()
 try:
  done=subprocess.run([sys.executable,'-m','scripts.experimental_multipeak_check','--worker',json.dumps([c,task,cfg,str(dest)])],cwd=ROOT,capture_output=True,text=True,timeout=60);(out/f'CO18_{i}.log').write_text(done.stdout+'\n'+done.stderr);record=json.loads(dest.read_text()) if done.returncode==0 else dict(status='error',task=task,returncode=done.returncode)
 except subprocess.TimeoutExpired: record=dict(status='timeout',task=task,timeout_seconds=60)
 record.update(case=c['name'],label=f'CO18_{i}',wall_seconds=time.monotonic()-start);results.append(record);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(i,record['status'],record.get('result',{}).get('normalized_rmse'),flush=True)
